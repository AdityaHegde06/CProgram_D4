/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int main() 
{
    int m1, m2, m3, m4, m5, per;
    printf("Enter marks in five subjects: ");
    scanf("%d %d %d %d %d", &m1, &m2, &m3, &m4, &m5);
    
   per = ((float)(m1 + m2 + m3 + m4 + m5) / 500) * 100;
    
    if (per >= 60) {
        printf("First division\n");
    }
    else if (per >= 50) {
        printf("Second division\n");
    }
    else if (per >= 40) {
        printf("Third division\n");
    }
    else {
        printf("Fail\n");
    }
    
    return 0;
}