/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//insurance of driver_using logical operators
#include <stdio.h>

int main()
{
    char sex ,ms;
    int age;
    printf("Enter age,sex and maritial status");
    scanf("%d\n%c\n%c\n",&age,&sex,&ms);
    if((ms=='M')||(ms=='U'&&sex=='M'&&age>30)||(ms=='U'&&sex=='F'&&age>25))
    {
    printf("Driver should me insured");
    }
    else
    {
    printf("Driver should me insured");
    }

    return 0;
}
