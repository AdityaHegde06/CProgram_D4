/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int m1,m2,m3,m4,m5,per;
    printf("Enter the marks in five subjects");
    scanf("%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5);
    per=(m1+m2+m3+m4+m5)*100/500;
    if(per>=60)
    {
    printf("First Division");
    }
    else
    {
        if(per>=50)
        printf("Second divison\n");
        else
        {
            if(per>=40)
            printf("Third Division\n");
            else
             printf("fail\n");
            }
        }
    return 0;
}
